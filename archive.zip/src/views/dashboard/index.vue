<template>
  <div class="dashboard">
    <h1>仪表盘</h1>
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.dashboard {
  padding: 20px;
}
</style> 