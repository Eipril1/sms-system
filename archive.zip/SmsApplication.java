@SpringBootApplication
@EnableKnife4j
public class SmsApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmsApplication.class, args);
    }
} 